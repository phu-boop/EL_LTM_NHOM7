"""
TCP OPTIMIZATION EXAMPLES - PYTHON
===================================
Minh họa các phương pháp tối ưu hóa giao thức TCP trong Python
Bao gồm:
1. Tối ưu TCP Window Size (Buffer Size)
2. Tắt Nagle's Algorithm (TCP_NODELAY)
3. Bật TCP Keep-Alive
4. Socket Reuse (SO_REUSEADDR & SO_REUSEPORT)
5. Timeout Configuration
6. TCP Quick ACK
7. Congestion Control Algorithm
8. TCP Optimized Server Example
9. TCP Optimized Client Example
10. Performance Benchmark
"""

import socket
import struct
import time
import threading
from typing import Optional, Tuple

# ============================================================================
# 1. TỐI ƯU TCP WINDOW SIZE (Buffer Size)
# ============================================================================

def optimize_tcp_window_size(sock: socket.socket, recv_buf_size: int = 262144, 
                             send_buf_size: int = 262144) -> None:
    """
    Tối ưu kích thước buffer TCP để tăng throughput
    
    Args:
        sock: Socket object
        recv_buf_size: Kích thước receive buffer (mặc định: 256KB)
        send_buf_size: Kích thước send buffer (mặc định: 256KB)
    """
    print(f"\n{'='*60}")
    print("1. TỐI ƯU TCP WINDOW SIZE")
    print(f"{'='*60}")
    
    # Lấy giá trị hiện tại
    current_recv = sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    current_send = sock.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)
    
    print(f"Receive Buffer - Trước: {current_recv} bytes")
    print(f"Send Buffer - Trước: {current_send} bytes")
    
    # Set buffer size mới
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, recv_buf_size)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, send_buf_size)
    
    # Verify
    new_recv = sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    new_send = sock.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)
    
    print(f"Receive Buffer - Sau: {new_recv} bytes")
    print(f"Send Buffer - Sau: {new_send} bytes")
    print("✓ Window size đã được tối ưu!")


# ============================================================================
# 2. TẮT NAGLE'S ALGORITHM (TCP_NODELAY)
# ============================================================================

def disable_nagle_algorithm(sock: socket.socket) -> None:
    """
    Tắt Nagle's algorithm để giảm latency
    Phù hợp cho ứng dụng real-time (game, chat, streaming)
    """
    print(f"\n{'='*60}")
    print("2. TẮT NAGLE'S ALGORITHM (TCP_NODELAY)")
    print(f"{'='*60}")
    
    # Get current state
    current = sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY)
    print(f"TCP_NODELAY - Trước: {bool(current)}")
    
    # Disable Nagle's algorithm
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    
    new = sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY)
    print(f"TCP_NODELAY - Sau: {bool(new)}")
    print("✓ Nagle's algorithm đã được tắt!")
    print("  → Dữ liệu sẽ được gửi ngay lập tức, giảm latency")


# ============================================================================
# 3. BẬT TCP KEEP-ALIVE
# ============================================================================

def enable_keepalive(sock: socket.socket, idle: int = 60, 
                     interval: int = 10, count: int = 5) -> None:
    """
    Bật TCP Keep-Alive để duy trì kết nối và phát hiện connection drop
    
    Args:
        sock: Socket object
        idle: Thời gian idle trước khi gửi probe đầu tiên (giây)
        interval: Khoảng thời gian giữa các probe (giây)
        count: Số probe trước khi ngắt kết nối
    """
    print(f"\n{'='*60}")
    print("3. BẬT TCP KEEP-ALIVE")
    print(f"{'='*60}")
    
    # Enable SO_KEEPALIVE
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    print("✓ SO_KEEPALIVE: Enabled")
    
    # Configure keep-alive parameters (Linux/Unix)
    try:
        if hasattr(socket, 'TCP_KEEPIDLE'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle)
            print(f"  → TCP_KEEPIDLE: {idle}s (thời gian idle)")
        
        if hasattr(socket, 'TCP_KEEPINTVL'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval)
            print(f"  → TCP_KEEPINTVL: {interval}s (interval giữa probes)")
        
        if hasattr(socket, 'TCP_KEEPCNT'):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count)
            print(f"  → TCP_KEEPCNT: {count} (số probes tối đa)")
    except AttributeError:
        print("  ⚠ Platform không hỗ trợ TCP Keep-Alive parameters")
    
    print("✓ Keep-Alive đã được cấu hình!")


# ============================================================================
# 4. SOCKET REUSE (SO_REUSEADDR & SO_REUSEPORT)
# ============================================================================

def enable_socket_reuse(sock: socket.socket) -> None:
    """
    Cho phép reuse address và port để restart server nhanh hơn
    """
    print(f"\n{'='*60}")
    print("4. SOCKET REUSE")
    print(f"{'='*60}")
    
    # SO_REUSEADDR: Cho phép bind vào địa chỉ đang ở TIME_WAIT
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print("✓ SO_REUSEADDR: Enabled")
    print("  → Có thể restart server ngay mà không cần đợi TIME_WAIT")
    
    # SO_REUSEPORT: Nhiều socket có thể bind cùng port (Linux 3.9+)
    if hasattr(socket, 'SO_REUSEPORT'):
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        print("✓ SO_REUSEPORT: Enabled")
        print("  → Load balancing giữa nhiều processes")
    else:
        print("⚠ SO_REUSEPORT không được hỗ trợ trên platform này")


# ============================================================================
# 5. TIMEOUT CONFIGURATION
# ============================================================================

def configure_timeout(sock: socket.socket, timeout: Optional[float] = 30.0) -> None:
    """
    Cấu hình timeout để tránh blocking vô thời hạn
    
    Args:
        sock: Socket object
        timeout: Timeout in seconds (None = blocking mode)
    """
    print(f"\n{'='*60}")
    print("5. TIMEOUT CONFIGURATION")
    print(f"{'='*60}")
    
    old_timeout = sock.gettimeout()
    print(f"Timeout - Trước: {old_timeout}")
    
    sock.settimeout(timeout)
    
    new_timeout = sock.gettimeout()
    print(f"Timeout - Sau: {new_timeout}s")
    print("✓ Timeout đã được cấu hình!")


# ============================================================================
# 6. TCP QUICKACK (Giảm độ trễ ACK)
# ============================================================================

def enable_quickack(sock: socket.socket) -> None:
    """
    Bật TCP Quick ACK để giảm độ trễ (Linux only)
    """
    print(f"\n{'='*60}")
    print("6. TCP QUICKACK")
    print(f"{'='*60}")
    
    if hasattr(socket, 'TCP_QUICKACK'):
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_QUICKACK, 1)
        print("✓ TCP_QUICKACK: Enabled")
        print("  → ACKs được gửi ngay lập tức, giảm round-trip delay")
    else:
        print("⚠ TCP_QUICKACK không được hỗ trợ (chỉ có trên Linux)")


# ============================================================================
# 7. CONGESTION CONTROL ALGORITHM
# ============================================================================

def set_congestion_control(sock: socket.socket, algorithm: str = 'cubic') -> None:
    """
    Thiết lập thuật toán congestion control (Linux only)
    
    Các thuật toán phổ biến:
    - cubic: Mặc định, tốt cho high-bandwidth networks
    - reno: Classic, stable
    - bbr: Google's BBR, tối ưu cho networks có loss
    - vegas: Delay-based
    """
    print(f"\n{'='*60}")
    print("7. CONGESTION CONTROL ALGORITHM")
    print(f"{'='*60}")
    
    if hasattr(socket, 'TCP_CONGESTION'):
        try:
            # Get current algorithm
            current = sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_CONGESTION, 16)
            current = current.decode('utf-8').rstrip('\x00')
            print(f"Algorithm - Trước: {current}")
            
            # Set new algorithm
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_CONGESTION, 
                          algorithm.encode('utf-8'))
            
            # Verify
            new = sock.getsockopt(socket.IPPROTO_TCP, socket.TCP_CONGESTION, 16)
            new = new.decode('utf-8').rstrip('\x00')
            print(f"Algorithm - Sau: {new}")
            print(f"✓ Congestion control đã được set thành '{algorithm}'")
        except Exception as e:
            print(f"⚠ Không thể set congestion control: {e}")
            print(f"  Có thể algorithm '{algorithm}' chưa được load vào kernel")
    else:
        print("⚠ TCP_CONGESTION không được hỗ trợ (chỉ có trên Linux)")


# ============================================================================
# 8. TCP OPTIMIZED SERVER EXAMPLE
# ============================================================================

class OptimizedTCPServer:
    """
    TCP Server được tối ưu hóa với tất cả các kỹ thuật trên
    """
    
    def __init__(self, host: str = '0.0.0.0', port: int = 8888):
        self.host = host
        self.port = port
        self.sock = None
        
    def create_optimized_socket(self) -> socket.socket:
        """Tạo socket với các tối ưu hóa"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        print(f"\n{'='*60}")
        print("CREATING OPTIMIZED TCP SERVER SOCKET")
        print(f"{'='*60}")
        
        # Apply all optimizations
        enable_socket_reuse(sock)
        optimize_tcp_window_size(sock, recv_buf_size=524288, send_buf_size=524288)
        disable_nagle_algorithm(sock)
        enable_keepalive(sock, idle=60, interval=10, count=5)
        # Don't set timeout on listening socket - let it block
        enable_quickack(sock)
        set_congestion_control(sock, 'cubic')
        
        return sock
    
    def start(self):
        """Khởi động server"""
        self.sock = self.create_optimized_socket()
        
        print(f"\n{'='*60}")
        print(f"🚀 STARTING SERVER ON {self.host}:{self.port}")
        print(f"{'='*60}")
        
        try:
            self.sock.bind((self.host, self.port))
            self.sock.listen(128)  # Backlog queue size
            print(f"✓ Server đang lắng nghe trên {self.host}:{self.port}")
            print("  Waiting for connections...\n")
            
            while True:
                try:
                    client_sock, addr = self.sock.accept()
                    print(f"✓ New connection from {addr}")
                    
                    # Tối ưu client socket
                    disable_nagle_algorithm(client_sock)
                    optimize_tcp_window_size(client_sock)
                    
                    # Handle in separate thread
                    thread = threading.Thread(target=self.handle_client, 
                                            args=(client_sock, addr))
                    thread.daemon = True
                    thread.start()
                except socket.timeout:
                    # This is fine, just check for KeyboardInterrupt
                    continue
                    
        except KeyboardInterrupt:
            print("\n\n⚠ Server shutting down...")
        finally:
            if self.sock:
                self.sock.close()
                print("✓ Server socket closed")
    
    def handle_client(self, client_sock: socket.socket, addr: Tuple):
        """Xử lý client connection"""
        try:
            # Send welcome message
            welcome = f"Welcome to Optimized TCP Server! Connected from {addr}\n"
            client_sock.sendall(welcome.encode('utf-8'))
            print(f"→ Sent welcome message to {addr}")
            
            # Echo server loop
            while True:
                data = client_sock.recv(4096)
                if not data:
                    break
                
                message = data.decode('utf-8').strip()
                print(f"← Received from {addr}: {message}")
                
                # Echo back
                response = f"ECHO: {message}\n"
                client_sock.sendall(response.encode('utf-8'))
                print(f"→ Echoed back to {addr}")
                
        except socket.timeout:
            print(f"✗ Timeout from {addr}")
        except Exception as e:
            print(f"✗ Error handling {addr}: {e}")
        finally:
            client_sock.close()
            print(f"✓ Connection closed: {addr}")


# ============================================================================
# 9. TCP OPTIMIZED CLIENT EXAMPLE
# ============================================================================

class OptimizedTCPClient:
    """
    TCP Client được tối ưu hóa
    """
    
    def __init__(self, host: str = '127.0.0.1', port: int = 8888):
        self.host = host
        self.port = port
        self.sock = None
    
    def connect(self):
        """Kết nối tới server với socket được tối ưu"""
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        print(f"\n{'='*60}")
        print("CREATING OPTIMIZED TCP CLIENT SOCKET")
        print(f"{'='*60}")
        
        # Apply optimizations
        optimize_tcp_window_size(self.sock)
        disable_nagle_algorithm(self.sock)
        enable_keepalive(self.sock)
        configure_timeout(self.sock, timeout=10.0)
        
        print(f"\n🔌 Connecting to {self.host}:{self.port}...")
        
        try:
            start_time = time.time()
            self.sock.connect((self.host, self.port))
            connect_time = (time.time() - start_time) * 1000
            
            print(f"✓ Connected successfully! (Latency: {connect_time:.2f}ms)")
            return True
            
        except Exception as e:
            print(f"✗ Connection failed: {e}")
            return False
    
    def send_message(self, message: str):
        """Gửi message và nhận response"""
        if not self.sock:
            print("✗ Not connected!")
            return
        
        try:
            # Send
            start_time = time.time()
            self.sock.sendall(message.encode('utf-8'))
            
            # Receive
            response = self.sock.recv(4096)
            rtt = (time.time() - start_time) * 1000
            
            print(f"→ Sent: {message}")
            print(f"← Received: {response.decode('utf-8')}")
            print(f"  RTT: {rtt:.2f}ms")
            
        except Exception as e:
            print(f"✗ Error: {e}")
    
    def close(self):
        """Đóng connection"""
        if self.sock:
            self.sock.close()
            print("✓ Connection closed")


# ============================================================================
# 10. PERFORMANCE BENCHMARK
# ============================================================================

def benchmark_tcp_optimization(host: str = '127.0.0.1', port: int = 8888, 
                              num_requests: int = 100):
    """
    Benchmark hiệu suất với và không có optimization
    """
    print(f"\n{'='*60}")
    print("PERFORMANCE BENCHMARK")
    print(f"{'='*60}")
    
    message = "Hello TCP Optimization!" * 10  # ~230 bytes
    
    # Test 1: Without optimization
    print(f"\n📊 Test 1: DEFAULT SOCKET (No optimization)")
    print(f"   Sending {num_requests} requests...")
    
    sock1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock1.connect((host, port))
    
    start = time.time()
    for i in range(num_requests):
        sock1.sendall(message.encode('utf-8'))
        sock1.recv(4096)
    elapsed1 = time.time() - start
    sock1.close()
    
    print(f"   ✓ Completed in {elapsed1:.3f}s")
    print(f"   → Throughput: {num_requests/elapsed1:.1f} req/s")
    
    # Test 2: With optimization
    print(f"\n📊 Test 2: OPTIMIZED SOCKET")
    print(f"   Sending {num_requests} requests...")
    
    sock2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    optimize_tcp_window_size(sock2)
    disable_nagle_algorithm(sock2)
    sock2.connect((host, port))
    
    start = time.time()
    for i in range(num_requests):
        sock2.sendall(message.encode('utf-8'))
        sock2.recv(4096)
    elapsed2 = time.time() - start
    sock2.close()
    
    print(f"   ✓ Completed in {elapsed2:.3f}s")
    print(f"   → Throughput: {num_requests/elapsed2:.1f} req/s")
    
    # Comparison
    improvement = ((elapsed1 - elapsed2) / elapsed1) * 100
    print(f"\n📈 IMPROVEMENT: {improvement:+.1f}%")
    if improvement > 0:
        print(f"   ✓ Optimized socket nhanh hơn!")
    else:
        print(f"   ⚠ Kết quả phụ thuộc vào network conditions")


# ============================================================================
# MAIN DEMO
# ============================================================================

def main():
    """
    Demo các tính năng tối ưu TCP
    """
    print("\n" + "="*60)
    print("TCP OPTIMIZATION DEMO - PYTHON")
    print("="*60)
    print("\nChọn chế độ:")
    print("1. Demo tất cả các tối ưu hóa")
    print("2. Chạy TCP Server (optimized)")
    print("3. Chạy TCP Client (optimized)")
    print("4. Benchmark hiệu suất")
    
    choice = input("\nLựa chọn của bạn (1-4): ").strip()
    
    if choice == '1':
        # Demo all optimizations
        demo_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        optimize_tcp_window_size(demo_sock)
        disable_nagle_algorithm(demo_sock)
        enable_keepalive(demo_sock)
        enable_socket_reuse(demo_sock)
        configure_timeout(demo_sock, 30.0)
        enable_quickack(demo_sock)
        set_congestion_control(demo_sock, 'cubic')
        
        print(f"\n{'='*60}")
        print("✓ ĐÃ HOÀN TẤT DEMO TẤT CẢ CÁC TỐI ƯU HÓA!")
        print(f"{'='*60}")
        demo_sock.close()
        
    elif choice == '2':
        server = OptimizedTCPServer(host='0.0.0.0', port=8888)
        server.start()
        
    elif choice == '3':
        client = OptimizedTCPClient(host='127.0.0.1', port=8888)
        if client.connect():
            while True:
                msg = input("\nEnter message (or 'quit'): ").strip()
                if msg.lower() == 'quit':
                    break
                client.send_message(msg)
            client.close()
    
    elif choice == '4':
        print("\n⚠ Lưu ý: Cần có server đang chạy tại localhost:8888")
        input("Press Enter khi server đã sẵn sàng...")
        benchmark_tcp_optimization()
    
    else:
        print("✗ Lựa chọn không hợp lệ!")


if __name__ == "__main__":
    main()