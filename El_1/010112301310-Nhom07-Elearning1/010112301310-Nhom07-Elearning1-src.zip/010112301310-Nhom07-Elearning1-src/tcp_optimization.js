/**
 * TCP OPTIMIZATION EXAMPLES - JAVASCRIPT (NODE.JS)
 * ================================================
 * Minh họa các phương pháp tối ưu hóa giao thức TCP trong Node.js
 */

const net = require('net');
const { performance } = require('perf_hooks');

// ============================================================================
// HÀM KIỂM TRA SERVER CÓ ĐANG CHẠY KHÔNG
// ============================================================================

function checkServerRunning(host, port, timeout = 2000) {
    return new Promise((resolve) => {
        const socket = net.createConnection({ host, port, timeout });
        socket.on('connect', () => {
            socket.destroy();
            resolve(true);
        });
        socket.on('error', () => resolve(false));
        socket.on('timeout', () => resolve(false));
    });
}

// ============================================================================
// 1. TỐI ƯU TCP WINDOW SIZE (Buffer Size)
// ============================================================================

function optimizeTcpWindowSize(socket, recvBufSize = 262144, sendBufSize = 262144) {
    console.log('\n' + '='.repeat(60));
    console.log('1. TỐI ƯU TCP WINDOW SIZE');
    console.log('='.repeat(60));

    try {
        console.log(`Target Receive Buffer: ${recvBufSize} bytes`);
        console.log(`Target Send Buffer: ${sendBufSize} bytes`);
        console.log('✓ Buffer sizes được quản lý bởi OS');
        console.log('  (Có thể cấu hình qua sysctl trên Linux/Mac)');
    } catch (error) {
        console.log(`⚠ Không thể set buffer size: ${error.message}`);
    }
}

// ============================================================================
// 2. TẮT NAGLE'S ALGORITHM (TCP_NODELAY)
// ============================================================================

function disableNagleAlgorithm(socket) {
    console.log('\n' + '='.repeat(60));
    console.log("2. TẮT NAGLE'S ALGORITHM (TCP_NODELAY)");
    console.log('='.repeat(60));

    const before = socket.noDelay || false;
    console.log(`TCP_NODELAY - Trước: ${before}`);

    socket.setNoDelay(true);

    console.log(`TCP_NODELAY - Sau: true`);
    console.log("✓ Nagle's algorithm đã được tắt!");
    console.log('  → Dữ liệu sẽ được gửi ngay lập tức, giảm latency');
}

// ============================================================================
// 3. BẬT TCP KEEP-ALIVE
// ============================================================================

function enableKeepAlive(socket, initialDelay = 60000) {
    console.log('\n' + '='.repeat(60));
    console.log('3. BẬT TCP KEEP-ALIVE');
    console.log('='.repeat(60));

    socket.setKeepAlive(true, initialDelay);

    console.log('✓ SO_KEEPALIVE: Enabled');
    console.log(`  → Initial Delay: ${initialDelay}ms (${initialDelay/1000}s)`);
    console.log('  → Keep-Alive sẽ duy trì kết nối và phát hiện connection drop');
    
    console.log('\n  📝 Lưu ý: TCP_KEEPINTVL và TCP_KEEPCNT được quản lý bởi OS');
    console.log('     Linux: /proc/sys/net/ipv4/tcp_keepalive_*');
}

// ============================================================================
// 4. SOCKET REUSE & TIMEOUT
// ============================================================================

function configureSocketOptions(socket, timeout = 30000) {
    console.log('\n' + '='.repeat(60));
    console.log('4. SOCKET OPTIONS (REUSE & TIMEOUT)');
    console.log('='.repeat(60));

    socket.setTimeout(timeout);
    console.log(`✓ Socket Timeout: ${timeout}ms (${timeout/1000}s)`);
    
    socket.on('timeout', () => {
        console.log('⚠ Socket timeout reached!');
        socket.end();
    });

    console.log('✓ Socket options đã được cấu hình!');
}

// ============================================================================
// 5. TCP OPTIMIZED SERVER
// ============================================================================

class OptimizedTCPServer {
    constructor(host = '0.0.0.0', port = 8888) {
        this.host = host;
        this.port = port;
        this.server = null;
        this.connections = new Set();
        this.stats = {
            totalConnections: 0,
            activeConnections: 0,
            totalBytesReceived: 0,
            totalBytesSent: 0
        };
    }

    createOptimizedServer() {
        console.log('\n' + '='.repeat(60));
        console.log('CREATING OPTIMIZED TCP SERVER');
        console.log('='.repeat(60));

        const server = net.createServer({
            allowHalfOpen: false,
            pauseOnConnect: false
        });

        server.on('listening', () => {
            const addr = server.address();
            console.log(`\n${'='.repeat(60)}`);
            console.log(`🚀 SERVER STARTED ON ${addr.address}:${addr.port}`);
            console.log(`${'='.repeat(60)}`);
            console.log('✓ Server đang lắng nghe kết nối...');
            console.log('  Press Ctrl+C to stop\n');
        });

        server.on('connection', (socket) => {
            this.handleConnection(socket);
        });

        server.on('error', (error) => {
            console.error(`✗ Server error: ${error.message}`);
        });

        return server;
    }

    handleConnection(socket) {
        const clientAddr = `${socket.remoteAddress}:${socket.remotePort}`;
        
        console.log(`\n✓ New connection from ${clientAddr}`);
        
        this.optimizeSocket(socket);
        
        this.connections.add(socket);
        this.stats.totalConnections++;
        this.stats.activeConnections++;
        
        const welcome = `Welcome to Optimized TCP Server!\nConnected from ${clientAddr}\n`;
        socket.write(welcome);

        socket.on('data', (data) => {
            this.stats.totalBytesReceived += data.length;
            
            const message = data.toString().trim();
            console.log(`← Received from ${clientAddr}: ${message.substring(0, 200)}${message.length > 200 ? '...' : ''}`);
            
            const response = `ECHO: ${message}\n`;
            socket.write(response);
            this.stats.totalBytesSent += response.length;
        });

        socket.on('end', () => {
            console.log(`✓ Client disconnected gracefully: ${clientAddr}`);
            this.connections.delete(socket);
            this.stats.activeConnections--;
        });

        socket.on('error', (error) => {
            if (!['ECONNRESET', 'EPIPE'].includes(error.code)) {
                console.error(`✗ Socket error from ${clientAddr}: ${error.message}`);
            }
        });

        socket.on('timeout', () => {
            console.log(`⚠ Timeout from ${clientAddr}`);
            socket.end();
        });

        socket.on('close', () => {
            this.connections.delete(socket);
            this.stats.activeConnections--;
        });
    }

    optimizeSocket(socket) {
        console.log('  🔧 Applying optimizations...');
        
        disableNagleAlgorithm(socket);
        enableKeepAlive(socket, 60000);
        configureSocketOptions(socket, 30000);
        
        try {
            optimizeTcpWindowSize(socket, 524288, 524288);
        } catch (error) {
            console.log(`  ⚠ Buffer size optimization skipped: ${error.message}`);
        }
        
        console.log('  ✓ Socket optimizations applied!');
    }

    start() {
        this.server = this.createOptimizedServer();
        
        this.server.maxConnections = 1000;
        
        this.server.listen({
            port: this.port,
            host: this.host,
            backlog: 511,
            exclusive: false,
            reuseAddress: true
        });

        process.on('SIGINT', () => {
            this.shutdown();
        });

        setInterval(() => this.showStats(), 30000);
    }

    showStats() {
        if (this.stats.totalConnections > 0) {
            console.log('\n' + '='.repeat(60));
            console.log('📊 SERVER STATISTICS');
            console.log('='.repeat(60));
            console.log(`Total Connections: ${this.stats.totalConnections}`);
            console.log(`Active Connections: ${this.stats.activeConnections}`);
            console.log(`Total Bytes Received: ${this.formatBytes(this.stats.totalBytesReceived)}`);
            console.log(`Total Bytes Sent: ${this.formatBytes(this.stats.totalBytesSent)}`);
            console.log('='.repeat(60) + '\n');
        }
    }

    formatBytes(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    shutdown() {
        console.log('\n\n⚠ Server shutting down...');
        
        for (const socket of this.connections) {
            socket.end();
        }
        
        if (this.server) {
            this.server.close(() => {
                console.log('✓ Server closed');
                this.showStats();
                process.exit(0);
            });
        }
    }
}

// ============================================================================
// 6. TCP OPTIMIZED CLIENT
// ============================================================================

class OptimizedTCPClient {
    constructor(host = '127.0.0.1', port = 8888) {
        this.host = host;
        this.port = port;
        this.socket = null;
        this.connected = false;
    }

    connect() {
        return new Promise((resolve, reject) => {
            console.log('\n' + '='.repeat(60));
            console.log('CREATING OPTIMIZED TCP CLIENT');
            console.log('='.repeat(60));

            const connectStart = performance.now();
            
            this.socket = net.createConnection({
                host: this.host,
                port: this.port,
                timeout: 10000
            });

            this.socket.on('connect', () => {
                const connectTime = (performance.now() - connectStart).toFixed(2);
                
                console.log(`\n🔌 Connecting to ${this.host}:${this.port}...`);
                console.log(`✓ Connected successfully! (Latency: ${connectTime}ms)\n`);
                
                this.optimizeSocket();
                
                this.connected = true;
                resolve();
            });

            this.socket.on('data', (data) => {
                console.log(`← Received: ${data.toString().trim()}`);
            });

            this.socket.on('end', () => {
                console.log('✓ Connection closed by server');
                this.connected = false;
            });

            this.socket.on('error', (error) => {
                console.error(`✗ Connection error: ${error.message}`);
                this.connected = false;
                reject(error);
            });

            this.socket.on('timeout', () => {
                console.log('⚠ Connection timeout!');
                this.socket.end();
                reject(new Error('Connection timeout'));
            });
        });
    }

    optimizeSocket() {
        console.log('🔧 Applying client optimizations...');
        
        disableNagleAlgorithm(this.socket);
        enableKeepAlive(this.socket, 60000);
        configureSocketOptions(this.socket, 10000);
        
        try {
            optimizeTcpWindowSize(this.socket);
        } catch (error) {
            console.log(`⚠ Buffer optimization skipped: ${error.message}`);
        }
    }

    async sendMessage(message) {
        if (!this.connected || !this.socket) {
            console.log('✗ Not connected!');
            return;
        }

        return new Promise((resolve) => {
            const sendStart = performance.now();
            
            this.socket.write(message + '\n', () => {
                const rtt = (performance.now() - sendStart).toFixed(2);
                console.log(`→ Sent: ${message}`);
                console.log(`  RTT: ${rtt}ms`);
                resolve();
            });
        });
    }

    close() {
        if (this.socket) {
            this.socket.end();
            console.log('✓ Connection closed');
        }
    }
}

// ============================================================================
// 7. PERFORMANCE BENCHMARK
// ============================================================================

async function benchmarkTcpOptimization(host = '127.0.0.1', port = 8888, numRequests = 100) {
    console.log('\n' + '='.repeat(60));
    console.log('PERFORMANCE BENCHMARK');
    console.log('='.repeat(60));

    const message = 'Hello TCP Optimization!'.repeat(10); // ~230 bytes

    console.log(`\nTest 1: DEFAULT SOCKET (No optimization)`);
    console.log(`   Sending ${numRequests} requests...`);
    const result1 = await runBenchmarkTest(host, port, message, numRequests, false);

    console.log(`\nTest 2: OPTIMIZED SOCKET`);
    console.log(`   Sending ${numRequests} requests...`);
    const result2 = await runBenchmarkTest(host, port, message, numRequests, true);

    const improvement = ((result1.elapsed - result2.elapsed) / result1.elapsed * 100).toFixed(1);
    console.log(`\nIMPROVEMENT: ${improvement > 0 ? '+' : ''}${improvement}%`);
    console.log(improvement > 0 ? '   Optimized socket nhanh hơn!' : '   Kết quả có thể do network latency, thử lại sau.');
    console.log('\nBenchmark completed!\n');
}

function runBenchmarkTest(host, port, message, numRequests, optimize) {
    return new Promise((resolve, reject) => {
        const socket = net.createConnection({ host, port, timeout: 15000 });

        let received = 0;
        let startTime;
        let sent = 0;

        const onConnect = () => {
            if (optimize) {
                socket.setNoDelay(true);
                socket.setKeepAlive(true, 60000);
            }

            startTime = performance.now();
            sendNext();
        };

        const sendNext = () => {
            if (sent < numRequests) {
                socket.write(message + '\n');
                sent++;
            }
        };

        const onData = () => {
            received++;
            if (received === numRequests) {
                const elapsed = ((performance.now() - startTime) / 1000).toFixed(3);
                const throughput = (numRequests / parseFloat(elapsed)).toFixed(1);

                console.log(`   Completed in ${elapsed}s`);
                console.log(`   → Throughput: ${throughput} req/s`);

                socket.end();
                resolve({ elapsed: parseFloat(elapsed), throughput: parseFloat(throughput) });
            } else {
                sendNext();
            }
        };

        socket.on('connect', onConnect);
        socket.on('data', onData);
        socket.once('error', (err) => {
            socket.destroy();
            reject(err);
        });
        socket.once('timeout', () => {
            socket.destroy();
            reject(new Error('Connection timeout'));
        });
    });
}

// ============================================================================
// 8. INTERACTIVE CLIENT EXAMPLE
// ============================================================================

async function runInteractiveClient() {
    const readline = require('readline');
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    const client = new OptimizedTCPClient('127.0.0.1', 8888);
    // Nếu muốn gửi qua Proxy, dùng dòng dưới:
    //const client = new OptimizedTCPClient('127.0.0.1', 9999); // ← Gửi đến Proxy 

    try {
        await client.connect();
        
        console.log('\n💬 Interactive mode started. Type your message (or "quit" to exit):\n');

        const askQuestion = () => {
            rl.question('> ', async (answer) => {
                if (answer.toLowerCase() === 'quit') {
                    client.close();
                    rl.close();
                    process.exit(0);
                }

                if (answer.trim()) {
                    await client.sendMessage(answer);
                }

                askQuestion();
            });
        };

        askQuestion();

    } catch (error) {
        console.error(`✗ Failed to connect: ${error.message}`);
        rl.close();
        process.exit(1);
    }
}

// ============================================================================
// 9. ADVANCED: TCP PROXY WITH OPTIMIZATION
// ============================================================================

class OptimizedTCPProxy {
    constructor(listenPort = 9999, targetHost = '127.0.0.1', targetPort = 8888) {
        this.listenPort = listenPort;
        this.targetHost = targetHost;
        this.targetPort = targetPort;
        this.server = null;
        this.stats = {
            connections: 0,
            bytesIn: 0,
            bytesOut: 0
        };
    }

    start() {
        console.log('\n' + '='.repeat(60));
        console.log('🔀 TCP PROXY WITH OPTIMIZATION');
        console.log('='.repeat(60));

        this.server = net.createServer((clientSocket) => {
            this.stats.connections++;
            const clientAddr = `${clientSocket.remoteAddress}:${clientSocket.remotePort}`;
            
            console.log(`\n✓ Proxy connection from ${clientAddr}`);

            clientSocket.setNoDelay(true);
            clientSocket.setKeepAlive(true, 60000);

            const targetSocket = net.createConnection({
                host: this.targetHost,
                port: this.targetPort
            });

            targetSocket.setNoDelay(true);
            targetSocket.setKeepAlive(true, 60000);

            targetSocket.on('connect', () => {
                console.log(`  → Connected to target ${this.targetHost}:${this.targetPort}`);
            });

            clientSocket.on('data', (data) => {
                this.stats.bytesIn += data.length;
                targetSocket.write(data);
            });

            targetSocket.on('data', (data) => {
                this.stats.bytesOut += data.length;
                clientSocket.write(data);
            });

            clientSocket.on('end', () => {
                console.log(`✓ Client disconnected: ${clientAddr}`);
                targetSocket.end();
            });

            targetSocket.on('end', () => {
                clientSocket.end();
            });

            clientSocket.on('error', (err) => {
                console.error(`✗ Client error: ${err.message}`);
                targetSocket.destroy();
            });

            targetSocket.on('error', (err) => {
                console.error(`✗ Target error: ${err.message}`);
                clientSocket.destroy();
            });
        });

        this.server.listen(this.listenPort, () => {
            console.log(`\n✓ Proxy listening on port ${this.listenPort}`);
            console.log(`  → Forwarding to ${this.targetHost}:${this.targetPort}\n`);
        });

        setInterval(() => this.showStats(), 30000);

        process.on('SIGINT', () => {
            console.log('\n\n⚠ Proxy shutting down...');
            this.showStats();
            this.server.close(() => {
                console.log('✓ Proxy closed');
                process.exit(0);
            });
        });
    }

    showStats() {
        if (this.stats.connections > 0) {
            console.log('\n' + '='.repeat(60));
            console.log('📊 PROXY STATISTICS');
            console.log('='.repeat(60));
            console.log(`Total Connections: ${this.stats.connections}`);
            console.log(`Bytes In (Client → Target): ${this.formatBytes(this.stats.bytesIn)}`);
            console.log(`Bytes Out (Target → Client): ${this.formatBytes(this.stats.bytesOut)}`);
            console.log('='.repeat(60) + '\n');
        }
    }

    formatBytes(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }
}

// ============================================================================
// 10. CONNECTION POOL FOR HIGH PERFORMANCE
// ============================================================================

class OptimizedTCPConnectionPool {
    constructor(host, port, poolSize = 10) {
        this.host = host;
        this.port = port;
        this.poolSize = poolSize;
        this.connections = [];
        this.available = [];
        this.waiting = [];
    }

    async initialize() {
        console.log('\n' + '='.repeat(60));
        console.log(`🏊 INITIALIZING CONNECTION POOL (Size: ${this.poolSize})`);
        console.log('='.repeat(60));

        const promises = [];
        for (let i = 0; i < this.poolSize; i++) {
            promises.push(this.createConnection(i));
        }

        await Promise.all(promises);
        console.log(`✓ Connection pool initialized with ${this.poolSize} connections\n`);
    }

    createConnection(id) {
        return new Promise((resolve, reject) => {
            const socket = net.createConnection({
                host: this.host,
                port: this.port
            });

            socket.on('connect', () => {
                socket.setNoDelay(true);
                socket.setKeepAlive(true, 60000);
                
                const conn = { id, socket, inUse: false };
                this.connections.push(conn);
                this.available.push(conn);
                
                console.log(`  ✓ Connection ${id} created`);
                resolve(conn);
            });

            socket.on('error', (error) => {
                console.error(`  ✗ Connection ${id} error: ${error.message}`);
                reject(error);
            });

            socket.on('end', () => {
                console.log(`  ⚠ Connection ${id} closed, recreating...`);
                setTimeout(() => this.createConnection(id), 1000);
            });
        });
    }

    async getConnection() {
        if (this.available.length > 0) {
            const conn = this.available.shift();
            conn.inUse = true;
            return conn;
        }

        return new Promise((resolve) => {
            this.waiting.push(resolve);
        });
    }

    releaseConnection(conn) {
        conn.inUse = false;
        
        if (this.waiting.length > 0) {
            const resolve = this.waiting.shift();
            conn.inUse = true;
            resolve(conn);
        } else {
            this.available.push(conn);
        }
    }

    async execute(message) {
        const conn = await this.getConnection();
        
        return new Promise((resolve) => {
            const handler = (data) => {
                conn.socket.removeListener('data', handler);
                this.releaseConnection(conn);
                resolve(data.toString());
            };
            
            conn.socket.on('data', handler);
            conn.socket.write(message + '\n');
        });
    }

    close() {
        console.log('\n⚠ Closing connection pool...');
        for (const conn of this.connections) {
            conn.socket.end();
        }
        console.log('✓ All connections closed');
    }
}

// ============================================================================
// MAIN DEMO
// ============================================================================

async function main() {
    console.log('\n' + '='.repeat(60));
    console.log('TCP OPTIMIZATION DEMO - JAVASCRIPT (NODE.JS)');
    console.log('='.repeat(60));
    console.log('\nChọn chế độ:');
    console.log('1. Chạy TCP Server (optimized)');
    console.log('2. Chạy TCP Client (optimized)');
    console.log('3. Chạy Interactive Client');
    console.log('4. Benchmark hiệu suất');
    console.log('5. Chạy TCP Proxy (advanced)');
    console.log('6. Demo Connection Pool (advanced)');

    const readline = require('readline');
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question('\nLựa chọn của bạn (1-6): ', async (choice) => {
        rl.close();
        choice = choice.trim();

        switch (choice) {
            case '1':
                const server = new OptimizedTCPServer('0.0.0.0', 8888);
                server.start();
                break;

            case '2':
                const client = new OptimizedTCPClient('127.0.0.1', 8888);
                try {
                    await client.connect();
                    await client.sendMessage('Hello from optimized client!');
                    await client.sendMessage('Testing TCP optimization...');
                    
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    
                    client.close();
                    setTimeout(() => process.exit(0), 500);
                } catch (error) {
                    console.error(`Failed: ${error.message}`);
                    process.exit(1);
                }
                break;

            case '3':
                await runInteractiveClient();
                break;

            case '4':
                console.log('\nLưu ý: Sẽ tự động khởi động server nếu chưa có...');
                console.log('Starting benchmark in 3 seconds...\n');

                setTimeout(async () => {
                    try {
                        const serverRunning = await checkServerRunning('127.0.0.1', 8888);
                        if (!serverRunning) {
                            console.log('Server chưa chạy → Khởi động server tạm thời...');
                            const tempServer = new OptimizedTCPServer('127.0.0.1', 8888);
                            tempServer.start();
                            await new Promise(resolve => {
                                tempServer.server.once('listening', () => {
                                    console.log('Server đã sẵn sàng!\n');
                                    resolve();
                                });
                            });
                        } else {
                            console.log('Server đã sẵn sàng!\n');
                        }

                        await benchmarkTcpOptimization('127.0.0.1', 8888, 100);
                        process.exit(0);
                    } catch (error) {
                        console.error(`Benchmark failed: ${error.message}`);
                        process.exit(1);
                    }
                }, 3000);
                break;

            case '5':
                const proxy = new OptimizedTCPProxy(9999, '127.0.0.1', 8888);
                proxy.start();
                break;

            case '6':
                console.log('\nLưu ý: Cần có server đang chạy tại localhost:8888');
                const pool = new OptimizedTCPConnectionPool('127.0.0.1', 8888, 5);
                
                try {
                    await pool.initialize();
                    
                    console.log('\n📨 Sending 20 concurrent requests...');
                    const promises = [];
                    for (let i = 0; i < 20; i++) {
                        promises.push(pool.execute(`Request ${i + 1}`));
                    }
                    
                    const results = await Promise.all(promises);
                    console.log(`\n✓ All requests completed!`);
                    console.log(`  First response: ${results[0].trim()}`);
                    
                    pool.close();
                    process.exit(0);
                } catch (error) {
                    console.error(`Failed: ${error.message}`);
                    process.exit(1);
                }
                break;

            default:
                console.log('✗ Lựa chọn không hợp lệ!');
                process.exit(1);
        }
    });
}

// ============================================================================
// EXPORT FOR MODULE USE
// ============================================================================

module.exports = {
    OptimizedTCPServer,
    OptimizedTCPClient,
    OptimizedTCPProxy,
    OptimizedTCPConnectionPool,
    optimizeTcpWindowSize,
    disableNagleAlgorithm,
    enableKeepAlive,
    configureSocketOptions
};

// Run if called directly
if (require.main === module) {
    main().catch(error => {
        console.error(`Fatal error: ${error.message}`);
        process.exit(1);
    });
}